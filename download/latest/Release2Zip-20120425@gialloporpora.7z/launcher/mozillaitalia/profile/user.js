// Non chiede se si vuole selezionare Firefox come browser predefinito
user_pref("browser.shell.checkDefaultBrowser",false);