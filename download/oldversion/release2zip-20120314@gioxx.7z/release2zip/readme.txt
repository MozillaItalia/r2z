Mozilla Italia Release2Zip Suite
Ultima mod. 2012-03-14
Rif. http://portami.li/?r2z
--
Il software viene rilasciato as-is, non esiste attualmente alcun supporto
per il prodotto. Tutto il materiale disponibile viene pubblicato nei blog degli sviluppatori.
Fare riferimento all'URL "Rif." sopra specificato.
_________________________________________________________________________________________________

---- README

-- Esempi:

	> fx2zip
	
		Senza parametri, equivalente a lanciarlo da Esplora risorse.
		Scarica l'ultima versione disponibile di Firefox e comprime in formato zip.

	> fx2zip 10.0
	
		Scarica la versione indicata nella riga di comando (nell'esempio la versione 10.0) e la comprime in formato ZIP

	> fx2zip 10.0 7z
	
		Scarica la versione indicata nella riga di comando (nell'esempio la versione 10.0) e produce un archivio in formato 7z

	> fx2zip 10.0 zip -mx9

		Scarica la versione indicata nella riga di comando (nell'esempio la versione 10.0) e la comprime in formato ZIP "ultracompresso".
		I valori di -mx sono:
		-mx0 -> nessuna compressione (modalit� copia)
		-mx1 compressione molto bassa (modalit� super veloce)
		-mx3 -> compressione bassa (modalit� veloce)
		-mx5 -> compressione normale
		-mx7 -> compressione maggiore
		-mx9 -> compressione massima
		
		Per maggiori dettagli: http://www.dotnetperls.com/7-zip-examples

	Tutti i parametri e gli esempi valgono anche per tb2zip.
	Per sm2zip � necessario invece specificare un numero di versione da scaricare in quanto non � disponibile attualmente un URL che propone il download del pacchetto pi� aggiornato, per un corretto uso sar� quindi obbligatorio richiamare il file batch da riga di comando.
	
-- Opzioni avanzate
	Le opzioni avanzate si possono impostare modificando con un editor di testo il file config.txt.
	E` possibile impostare la lingua (esempio fr per il francese) e di impostare lo script per includere/escludere i dizionari e il launcher dal pacchetto.
	
-- Scaricare i file della lingua
	Il file dwdict permette di scaricare i file necessari per i dizionari e la sillabazione dal sito di OpenOffice. 
	Lo script che costruisce il pacchetto avvia automaticamente il download di questi file (stessa lingua del programma) se non esiste una cartella dictionaries.
	Si consiglia di creare manualmente questa cartella e di inserire i file relativi alla lingua scaricandoli dalle pagine del progetto OpenOffice.
	Si possono includere pi� lingue, lo script � impostato per le lingue francese e italiano, per aggiungere altre lingue (sperando che funzioni) editare il file langs.txt inserendo il codice della lingua e l'url alla pagina sul sito di OpenOffice del progetto del dizionario.

 -- Software inclusi nel pacchetto:
	
	> Super Sed (versione modificata di sed che non necessita di DLL aggiuntive): http://sed.sourceforge.net/grabbag/ssed/
	> Wget: http://www.gnu.org/software/wget/
	> 7z, l'eseguibile utilizzabile da riga dei comandi: http://www.7-zip.org/
	
	A cosa servono?
	wget serve per eseguire il download dei file, sed per fare un, rozzo, parsing delle pagine web alla ricerca dei link e infine 7z serve per estrarre e creare gli archivi.
	
_________________________________________________________________________________________________

---- CHANGELOG (Versioni)

fx2zip 0.2 14/03/2012 (@Gioxx)
	Il download del pacchetto e tutti i file che permettono la lavorazione del file ZIP finale vengono ora scritti nella cartella "temp" presente all'interno della cartella principale della suite.
	A fine impacchettamento l'archivio verr� spostato in automatico sotto la cartella "archive", anch'essa presente nella root come "temp". Se esiste ancora, viene ordinata la cancellazione della cartella "core" / "firefox" utile alla creazione del file ZIP finale.
	Ancora oggi non � possibile evitare l'errore del WGET nel caso in cui il sito web selezionato autonomamente dal round-robin Mozilla non permetta il download batch del software.
	Quanto prima anche tb2zip verr� allineato a questo comportamento, che lascia pulita la cartella principale della suite durante la lavorazione batch.